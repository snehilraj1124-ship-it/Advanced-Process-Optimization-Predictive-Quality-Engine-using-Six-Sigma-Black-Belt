# Advanced Process Optimization & Predictive Quality Engine using Six Sigma Black Belt

## Overview

OptiSigma is a full-stack Six Sigma Black Belt portfolio project designed to demonstrate advanced process optimization, predictive quality analysis, statistical modeling, scenario simulation, and data-driven improvement planning.

The platform connects process measurements with operating parameters such as temperature, pressure, and cycle time. A multiple linear regression model estimates the relationship between these inputs and the observed quality outcome. A search-based optimization engine then evaluates operating combinations and identifies candidate settings close to the process target.

This project is intended as an educational and portfolio implementation of Black Belt-level analytical thinking. It demonstrates how process data can support root-cause investigation, prediction, optimization, and continuous improvement.

## Objectives

- Analyze process-performance data.
- Model relationships between process inputs and quality output.
- Quantify predictive model fit using R².
- Predict quality outcomes under different operating conditions.
- Search for improved operating parameter combinations.
- Compare baseline and optimized scenarios.
- Estimate defect probability as a scenario indicator.
- Connect process improvement with operational cost.
- Present analytical results through an executive dashboard.

## Six Sigma Black Belt Concepts Demonstrated

### DMAIC

**Define**
- Identify the process and quality objective.
- Define target, lower specification limit, and upper specification limit.

**Measure**
- Capture quality observations.
- Record process variables.
- Track defects and operational conditions.

**Analyze**
- Examine relationships between process inputs and quality.
- Use multiple linear regression.
- Review model fit through R².
- Compare operating scenarios.

**Improve**
- Search combinations of controllable process variables.
- Generate candidate operating windows.
- Compare predicted performance against target.

**Control**
- Preserve validated scenarios.
- Monitor observations over time.
- Extend the platform with SPC and alert rules.

## Predictive Model

The platform uses a multiple linear regression model:

`Quality = b0 + b1(Temperature) + b2(Pressure) + b3(Cycle Time)`

The coefficients are estimated from historical observations using the normal-equation approach.

### R²

R² measures the proportion of observed quality variation explained by the fitted model:

`R² = 1 - SSres / SStot`

A higher R² indicates a stronger fit to the observed sample, but it does not prove causation or guarantee future production performance.

## Optimization Engine

The optimization module evaluates a grid of candidate operating conditions and scores each candidate based on:

- Distance from the target quality value.
- Cycle-time penalty.

The result is a candidate setting rather than an automatic production recommendation.

Any real implementation should validate the candidate through controlled trials, engineering review, measurement-system analysis, and appropriate statistical testing before changing production settings.

## Scenario Analysis

Users can save operating scenarios with:

- Temperature
- Pressure
- Cycle time
- Predicted quality
- Defect-probability indicator

This supports structured comparison of baseline and improvement ideas.

## Cost & Improvement Perspective

Each process stores an estimated monthly operating cost. The dashboard also provides an illustrative improvement-savings view based on a 15% improvement assumption.

This is intentionally a portfolio-level financial illustration. Real savings calculations should use validated baseline costs, defect costs, throughput effects, labor, scrap, rework, and implementation costs.

## Core Modules

### Process Management
Create and manage process specifications, targets, departments, production volume, defects, and monthly operating cost.

### Observation Management
Capture historical quality measurements and controllable process parameters.

### Predictive Quality
Fit a multiple linear regression model and calculate model fit.

### Process Optimization
Search candidate parameter combinations against the target quality value.

### Scenario Simulation
Save and compare proposed operating settings.

### Executive Dashboard
Review observation volume, defects, defect rate, process portfolio, scenarios, and improvement-value indicators.

## Technology Stack

- Python
- Flask
- SQLite
- Jinja2
- HTML5
- CSS3
- Statistical regression
- Scenario optimization
- Six Sigma methodology

## Project Structure

```text
OptiSigma/
├── app.py
├── requirements.txt
├── README.md
├── schema.sql
├── .gitignore
└── templates/
    ├── base.html
    ├── dashboard.html
    ├── processes.html
    ├── observations.html
    └── optimization.html
```

## Installation

### 1. Clone the repository

```bash
git clone <your-repository-url>
cd OptiSigma
```

### 2. Create a virtual environment

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

macOS/Linux:

```bash
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the application

```bash
python app.py
```

Open:

`http://127.0.0.1:5000`

The SQLite database is initialized automatically on the first run.

## Example Workflow

1. Open the dashboard.
2. Review seeded manufacturing, energy, and operations processes.
3. Open Observations and review measurement data.
4. Select a process in Predictive Optimization.
5. Review regression coefficients and R².
6. Inspect the candidate optimized operating point.
7. Save a custom scenario.
8. Compare predicted quality with the process target.
9. Use the results as a starting point for further Six Sigma validation.

## Future Enhancements

- Full Design of Experiments (DOE)
- ANOVA
- Interaction effects
- Response Surface Methodology
- Confidence and prediction intervals
- Residual diagnostics
- Control charts
- Statistical process control rules
- Measurement System Analysis (MSA)
- Hypothesis testing
- Monte Carlo simulation
- Automated improvement-savings calculations
- Role-based access control
- CSV/Excel import
- Production database integration
- Advanced optimization algorithms

## Portfolio Progression

This project represents the **Six Sigma Black Belt** stage of a structured continuous-improvement portfolio:

1. White Belt — Process Mapping & Waste Intelligence
2. Yellow Belt — Defect & Root Cause Analysis
3. Green Belt — Process Capability & Statistical Quality Analytics
4. Black Belt — Advanced Process Optimization & Predictive Quality
5. Master Black Belt — Enterprise-Wide Continuous Improvement Intelligence

## Disclaimer

This is an educational portfolio project. The predictive and optimization calculations are simplified implementations intended to demonstrate analytical workflow and software engineering. They should not be used to change real industrial process settings without proper engineering validation, measurement-system verification, statistical testing, safety review, and controlled implementation.

## Author

Snehil Raj

B.Tech Electrical & Electronics Engineering  
Focus Areas: Data Analytics, Business Analytics, Operations, Energy Systems, Process Improvement

## License

For portfolio and educational use.
