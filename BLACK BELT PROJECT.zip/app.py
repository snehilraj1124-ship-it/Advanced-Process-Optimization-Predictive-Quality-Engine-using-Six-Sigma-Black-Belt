from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from statistics import mean, pstdev

app = Flask(__name__)
app.secret_key = "optisigma-black-belt"

DB = "optisigma.db"

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    with open("schema.sql", "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    count = conn.execute("SELECT COUNT(*) FROM processes").fetchone()[0]
    if count == 0:
        processes = [
            ("CNC Shaft Machining", "Manufacturing", 10.00, 9.80, 10.20, 420, 31, 14500),
            ("Battery Assembly", "Energy", 12.20, 11.80, 12.60, 360, 24, 18750),
            ("Order Fulfillment", "Operations", 14.00, 8.00, 20.00, 520, 38, 9200),
        ]
        conn.executemany("""INSERT INTO processes
            (name, department, target, lsl, usl, observations, defects, monthly_cost)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", processes)

        observations = [
            (1, 9.94, 82, 68, 18, 0),
            (1, 10.08, 91, 72, 21, 0),
            (1, 10.14, 96, 76, 23, 1),
            (1, 9.88, 77, 64, 17, 0),
            (1, 10.02, 86, 70, 19, 0),
            (1, 10.18, 101, 80, 25, 1),
            (2, 12.08, 73, 61, 16, 0),
            (2, 12.31, 84, 66, 18, 0),
            (2, 12.44, 96, 75, 22, 1),
            (2, 12.18, 70, 59, 15, 0),
            (2, 12.51, 103, 81, 24, 1),
            (2, 12.26, 79, 64, 17, 0),
            (3, 13.20, 66, 58, 14, 0),
            (3, 15.10, 88, 74, 19, 0),
            (3, 17.20, 112, 91, 27, 1),
            (3, 12.70, 61, 53, 13, 0),
            (3, 14.30, 76, 65, 16, 0),
            (3, 18.60, 126, 101, 31, 1),
        ]
        conn.executemany("""INSERT INTO observations
            (process_id, quality_value, temperature, pressure, cycle_time, defect)
            VALUES (?, ?, ?, ?, ?, ?)""", observations)

        scenarios = [
            (1, "Baseline", 82, 68, 18, 10.08, 0.0),
            (1, "Optimized Setup", 76, 64, 16, 10.01, 0.18),
            (2, "Stable Thermal Window", 78, 64, 17, 12.20, 0.22),
            (3, "Balanced Fulfillment", 72, 61, 15, 14.10, 0.16),
        ]
        conn.executemany("""INSERT INTO scenarios
            (process_id, name, temperature, pressure, cycle_time, predicted_quality, defect_probability)
            VALUES (?, ?, ?, ?, ?, ?, ?)""", scenarios)
    conn.commit()
    conn.close()

def regression(rows):
    # Multiple linear regression using normal equations:
    # y = b0 + b1*T + b2*P + b3*C
    if len(rows) < 4:
        return None
    X = [[1.0, float(r["temperature"]), float(r["pressure"]), float(r["cycle_time"])] for r in rows]
    y = [float(r["quality_value"]) for r in rows]
    n = len(X)
    m = 4
    A = [[sum(X[k][i] * X[k][j] for k in range(n)) for j in range(m)] for i in range(m)]
    B = [sum(X[k][i] * y[k] for k in range(n)) for i in range(m)]

    for i in range(m):
        pivot = max(range(i, m), key=lambda r: abs(A[r][i]))
        if abs(A[pivot][i]) < 1e-10:
            return None
        A[i], A[pivot] = A[pivot], A[i]
        B[i], B[pivot] = B[pivot], B[i]
        div = A[i][i]
        A[i] = [v / div for v in A[i]]
        B[i] /= div
        for r in range(m):
            if r == i:
                continue
            factor = A[r][i]
            A[r] = [A[r][c] - factor * A[i][c] for c in range(m)]
            B[r] -= factor * B[i]
    coeff = B
    preds = [sum(coeff[j] * X[i][j] for j in range(m)) for i in range(n)]
    ybar = mean(y)
    ss_tot = sum((v-ybar)**2 for v in y)
    ss_res = sum((y[i]-preds[i])**2 for i in range(n))
    r2 = 1 - ss_res/ss_tot if ss_tot else 0
    return {"coeff": coeff, "r2": r2}

def predict(model, t, p, c):
    b = model["coeff"]
    return b[0] + b[1]*t + b[2]*p + b[3]*c

def analyze_process(process_id):
    conn = db()
    p = conn.execute("SELECT * FROM processes WHERE id=?", (process_id,)).fetchone()
    rows = conn.execute("SELECT * FROM observations WHERE process_id=?", (process_id,)).fetchall()
    conn.close()
    model = regression(rows)
    return p, rows, model

@app.route("/")
def dashboard():
    conn = db()
    processes = conn.execute("SELECT * FROM processes ORDER BY id").fetchall()
    scenarios = conn.execute("""SELECT s.*, p.name AS process_name
                                FROM scenarios s JOIN processes p ON p.id=s.process_id
                                ORDER BY s.id DESC""").fetchall()
    total_obs = conn.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
    total_defects = conn.execute("SELECT COALESCE(SUM(defect),0) FROM observations").fetchone()[0]
    total_savings = conn.execute("""SELECT COALESCE(SUM(monthly_cost * 0.15),0)
                                    FROM processes""").fetchone()[0]
    conn.close()
    defect_rate = (total_defects / total_obs * 100) if total_obs else 0
    return render_template("dashboard.html", processes=processes, scenarios=scenarios,
                           total_obs=total_obs, total_defects=total_defects,
                           defect_rate=defect_rate, total_savings=total_savings)

@app.route("/processes", methods=["GET", "POST"])
def processes():
    conn = db()
    if request.method == "POST":
        name = request.form["name"].strip()
        department = request.form["department"].strip()
        target = float(request.form["target"])
        lsl = float(request.form["lsl"])
        usl = float(request.form["usl"])
        observations = int(request.form.get("observations", 0))
        defects = int(request.form.get("defects", 0))
        monthly_cost = float(request.form.get("monthly_cost", 0))
        conn.execute("""INSERT INTO processes
            (name, department, target, lsl, usl, observations, defects, monthly_cost)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (name, department, target, lsl, usl, observations, defects, monthly_cost))
        conn.commit()
        conn.close()
        flash("Process added successfully.")
        return redirect(url_for("processes"))
    data = conn.execute("SELECT * FROM processes ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("processes.html", processes=data)

@app.route("/observations", methods=["GET", "POST"])
def observations():
    conn = db()
    if request.method == "POST":
        conn.execute("""INSERT INTO observations
            (process_id, quality_value, temperature, pressure, cycle_time, defect)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (int(request.form["process_id"]), float(request.form["quality_value"]),
             float(request.form["temperature"]), float(request.form["pressure"]),
             float(request.form["cycle_time"]), int(request.form.get("defect", 0))))
        conn.commit()
        conn.close()
        flash("Observation recorded.")
        return redirect(url_for("observations"))
    rows = conn.execute("""SELECT o.*, p.name AS process_name
                           FROM observations o JOIN processes p ON p.id=o.process_id
                           ORDER BY o.id DESC""").fetchall()
    processes = conn.execute("SELECT * FROM processes ORDER BY name").fetchall()
    conn.close()
    return render_template("observations.html", observations=rows, processes=processes)

@app.route("/optimization", methods=["GET", "POST"])
def optimization():
    conn = db()
    processes = conn.execute("SELECT * FROM processes ORDER BY name").fetchall()
    selected_id = int(request.form.get("process_id", request.args.get("process_id", processes[0]["id"]))) if processes else None
    p = None
    rows = []
    model = None
    recommendations = []
    if selected_id:
        p, rows, model = analyze_process(selected_id)
        if model:
            current = predict(model, mean([r["temperature"] for r in rows]),
                              mean([r["pressure"] for r in rows]),
                              mean([r["cycle_time"] for r in rows]))
            best = None
            for t in range(60, 111, 5):
                for pr in range(55, 86, 5):
                    for c in range(12, 28, 2):
                        value = predict(model, t, pr, c)
                        distance = abs(value - p["target"])
                        score = distance + 0.002 * c
                        if best is None or score < best["score"]:
                            best = {"t": t, "p": pr, "c": c, "value": value, "score": score}
            recommendations = [
                f"Model R² = {model['r2']:.3f}; use the model as a decision-support signal, not as a substitute for process validation.",
                f"Current modeled quality at average operating conditions: {current:.3f}.",
                f"Search-based optimum candidate: temperature {best['t']}, pressure {best['p']}, cycle time {best['c']} → predicted quality {best['value']:.3f}.",
                f"Target quality is {p['target']:.3f}; validate the recommended operating window with controlled trials before production rollout."
            ]
    conn.close()
    return render_template("optimization.html", processes=processes, process=p, rows=rows,
                           model=model, recommendations=recommendations)

@app.route("/scenarios", methods=["POST"])
def scenarios():
    process_id = int(request.form["process_id"])
    name = request.form["name"].strip()
    t = float(request.form["temperature"])
    pr = float(request.form["pressure"])
    c = float(request.form["cycle_time"])
    p, rows, model = analyze_process(process_id)
    predicted = predict(model, t, pr, c) if model else p["target"]
    probability = min(0.95, max(0.01, abs(predicted - p["target"]) / max(abs(p["usl"]-p["lsl"]), 0.001)))
    conn = db()
    conn.execute("""INSERT INTO scenarios
        (process_id, name, temperature, pressure, cycle_time, predicted_quality, defect_probability)
        VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (process_id, name, t, pr, c, predicted, probability))
    conn.commit()
    conn.close()
    flash("Optimization scenario saved.")
    return redirect(url_for("optimization", process_id=process_id))

@app.route("/delete/process/<int:process_id>")
def delete_process(process_id):
    conn = db()
    conn.execute("DELETE FROM observations WHERE process_id=?", (process_id,))
    conn.execute("DELETE FROM scenarios WHERE process_id=?", (process_id,))
    conn.execute("DELETE FROM processes WHERE id=?", (process_id,))
    conn.commit()
    conn.close()
    flash("Process removed.")
    return redirect(url_for("processes"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
