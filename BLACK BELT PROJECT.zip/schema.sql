CREATE TABLE IF NOT EXISTS processes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    department TEXT NOT NULL,
    target REAL NOT NULL,
    lsl REAL NOT NULL,
    usl REAL NOT NULL,
    observations INTEGER DEFAULT 0,
    defects INTEGER DEFAULT 0,
    monthly_cost REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    process_id INTEGER NOT NULL,
    quality_value REAL NOT NULL,
    temperature REAL NOT NULL,
    pressure REAL NOT NULL,
    cycle_time REAL NOT NULL,
    defect INTEGER DEFAULT 0,
    FOREIGN KEY(process_id) REFERENCES processes(id)
);

CREATE TABLE IF NOT EXISTS scenarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    process_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    temperature REAL NOT NULL,
    pressure REAL NOT NULL,
    cycle_time REAL NOT NULL,
    predicted_quality REAL NOT NULL,
    defect_probability REAL NOT NULL,
    FOREIGN KEY(process_id) REFERENCES processes(id)
);
